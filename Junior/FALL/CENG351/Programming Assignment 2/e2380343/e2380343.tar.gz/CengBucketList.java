import java.util.ArrayList;

public class CengBucketList {

	private ArrayList<CengBucket> bList;

	public CengBucketList(){
	}

	public void deletePoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
	}

	public void addPoke(CengPoke poke)
	{
		// TODO: Empty Implementation
	}
	
	public void searchPoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
	}
	
	public void print()
	{
		// TODO: Empty Implementation
	}

	public int bucketCount()
	{
		// TODO: Return all bucket count.
		return 0;
	}

	public CengBucket bucketAtIndex(int index)
	{
		// TODO: Return corresponding bucket at index.
		return null;
	}
	

}
